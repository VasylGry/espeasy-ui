import { h, Component } from 'preact';

export class TestPage extends Component {
    render(props) {
        return (
            <h1>hello world </h1>
        );
    }
}

