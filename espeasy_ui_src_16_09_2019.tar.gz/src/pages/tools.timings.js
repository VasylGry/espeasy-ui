// timingstats_json

TXBuffer.startJsonStream();
stream_next_json_object_value(F("Build"), String(BUILD));